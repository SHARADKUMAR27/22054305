package com.Average_calculator.Average_calculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AverageCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
