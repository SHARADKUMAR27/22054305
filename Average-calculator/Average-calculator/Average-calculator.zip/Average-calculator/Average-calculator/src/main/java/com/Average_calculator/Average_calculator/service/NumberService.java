package com.Average_calculator.Average_calculator.service;

import com.Average_calculator.Average_calculator.model.CalculatorResponse;
import com.Average_calculator.Average_calculator.model.NumberResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Service
public class NumberService {
    private static final Logger LOGGER = Logger.getLogger(NumberService.class.getName());

    @Value("${window.size}")
    private int windowSize;

    @Value("${api.prime-url}")
    private String primeUrl;

    @Value("${api.fibonacci-url}")
    private String fibonacciUrl;

    @Value("${api.even-url}")
    private String evenUrl;

    @Value("${api.random-url}")
    private String randomUrl;

    @Value("${api.auth-url:http://20.244.56.144/auth/token}")
    private String authUrl;

    private final RestTemplate restTemplate;
    private final LinkedList<Integer> numberWindow = new LinkedList<>();

    @Autowired
    public NumberService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public CalculatorResponse processNumbers(String numberType) {
        // Store the previous state of the window before making any changes
        List<Integer> prevState = new ArrayList<>(numberWindow);

        // Fetch numbers from the appropriate API based on number type
        NumberResponse response = fetchNumbers(numberType);
        int[] fetchedNumbers = new int[0]; // Default empty array

        if (response != null && response.getNumbers() != null) {
            fetchedNumbers = response.getNumbers();

            // Process new numbers (add unique numbers to window)
            for (int number : fetchedNumbers) {
                // Only add unique numbers to the window
                if (!numberWindow.contains(number)) {
                    // If window is full, remove the oldest number
                    if (numberWindow.size() >= windowSize) {
                        numberWindow.removeFirst();
                    }
                    // Add the new number to the end of the window
                    numberWindow.add(number);
                }
            }
        }

        // Calculate the average of numbers in the window
        double avg = 0.0;
        if (!numberWindow.isEmpty()) {
            avg = numberWindow.stream()
                    .mapToInt(Integer::intValue)
                    .average()
                    .orElse(0.0);
        }

        // Create and return the response
        CalculatorResponse calculatorResponse = new CalculatorResponse();
        calculatorResponse.setWindowPrevState(prevState);
        calculatorResponse.setWindowCurrState(new ArrayList<>(numberWindow));
        calculatorResponse.setNumbers(fetchedNumbers);
        calculatorResponse.setAvg(Math.round(avg * 100.0) / 100.0); // Round to 2 decimal places

        return calculatorResponse;
    }

    private String getAuthToken() {
        try {
            // Create the request body with client credentials
            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("clientId", "296243d7-237d-4b30-9062-16402dad5f01");
            requestBody.put("clientSecret", "dGqCzdZDCffJGqGN");

            // Add other fields from your JWT
            requestBody.put("email", "22054305@kiit.ac.in");
            requestBody.put("rollNo", "22054305");
            requestBody.put("accessCode", "nwpwrZ");

            // Create headers if necessary
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Create the request entity
            HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);

            // Make the token request
            LOGGER.info("Attempting to get auth token from: " + authUrl);
            ResponseEntity<Map> responseEntity = restTemplate.exchange(
                    authUrl,
                    HttpMethod.POST,
                    requestEntity,
                    Map.class
            );

            // Extract the token from the response
            if (responseEntity.getStatusCode().is2xxSuccessful() && responseEntity.getBody() != null) {
                Map<String, Object> responseBody = responseEntity.getBody();
                LOGGER.info("Received token response: " + responseBody);
                // Adjust the field name based on the actual response structure
                String token = (String) responseBody.get("token");
                if (token == null) {
                    // Try other common field names if 'token' isn't found
                    token = (String) responseBody.get("access_token");
                }
                return token;
            } else {
                LOGGER.warning("Failed to get token: " + responseEntity.getStatusCode());
                return null;
            }
        } catch (Exception e) {
            LOGGER.warning("Error getting token: " + e.getMessage());
            return null;
        }
    }

    private NumberResponse fetchNumbers(String numberType) {
        String url = null;

        // Select the appropriate URL based on number type
        switch (numberType) {
            case "p":
                url = primeUrl;
                break;
            case "f":
                url = fibonacciUrl;
                break;
            case "e":
                url = evenUrl;
                break;
            case "r":
                url = randomUrl;
                break;
            default:
                LOGGER.warning("Invalid number type: " + numberType);
                return null;
        }

        try {
            // First try getting a fresh token
            String token = getAuthToken();
            if (token != null) {
                LOGGER.info("Got fresh token for API request");
                return makeApiRequestWithToken(url, token);
            }

            // If token generation fails, fall back to the hardcoded token
            LOGGER.info("Falling back to hardcoded token");
            String fallbackToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiZXhwIjoxNzQzNTk5NjcwLCJpYXQiOjE3NDM1OTkzNzAsImlzcyI6IkFmZm9yZG1lZCIsImp0aSI6IjI5NjI0M2Q3LTIzN2QtNGIzMC05MDYyLTE2NDAyZGFkNWYwMSIsInN1YiI6IjIyMDU0MzA1QGtpaXQuYWMuaW4ifSwiZW1haWwiOiIyMjA1NDMwNUBraWl0LmFjLmluIiwibmFtZSI6InNoYXJhZCBrdW1hciIsInJvbGxObyI6IjIyMDU0MzA1IiwiYWNjZXNzQ29kZSI6Im53cHdyWiIsImNsaWVudElEIjoiMjk2MjQzZDctMjM3ZC00YjMwLTkwNjItMTY0MDJkYWQ1ZjAxIiwiY2xpZW50U2VjcmV0IjoiZEdxQ3pkWkRDZmZKR3FHTiJ9.lebEu_muxKCGTvJKYDe-ToMl1gnJJk763ZJrGJwkmYs";
            return makeApiRequestWithToken(url, fallbackToken);

        } catch (RestClientException e) {
            LOGGER.warning("Error in fetchNumbers: " + e.getMessage());
            return null;
        }
    }

    private NumberResponse makeApiRequestWithToken(String url, String token) {
        try {
            // Create headers with authentication
            HttpHeaders headers = new HttpHeaders();

            // Try different auth header formats
            headers.set("Authorization", "Bearer " + token);

            // Create entity and make request
            HttpEntity<String> entity = new HttpEntity<>(headers);

            LOGGER.info("Sending request to: " + url);
            LOGGER.info("With Authorization header: Bearer " + token);

            ResponseEntity<NumberResponse> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    NumberResponse.class
            );

            return response.getBody();
        } catch (RestClientException e) {
            LOGGER.warning("Error fetching from " + url + ": " + e.getMessage());

            // If "Bearer" fails, try without it
            if (e.getMessage().contains("401 Unauthorized")) {
                try {
                    HttpHeaders headers = new HttpHeaders();
                    headers.set("Authorization", token);

                    HttpEntity<String> entity = new HttpEntity<>(headers);
                    LOGGER.info("Retrying without 'Bearer' prefix");

                    ResponseEntity<NumberResponse> response = restTemplate.exchange(
                            url,
                            HttpMethod.GET,
                            entity,
                            NumberResponse.class
                    );

                    return response.getBody();
                } catch (RestClientException innerEx) {
                    LOGGER.warning("Error on retry: " + innerEx.getMessage());
                }
            }
            return null;
        }
    }
}