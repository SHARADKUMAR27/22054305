package com.Average_calculator.Average_calculator.model;

import java.util.Arrays;
import lombok.Data;

@Data
public class NumberResponse {
    private int[] numbers;
    
    @Override
    public String toString() {
        return "NumberResponse{" +
                "numbers=" + Arrays.toString(numbers) +
                '}';
    }
}